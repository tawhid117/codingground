1. Click entryForm.jar
2. Enter data
3. Click viewForm.ja
4. Type user and pass and submit
5. "up.csv" contains usernames and passwords only
6. "userdata.csv" contains detail information